import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Homepage from '@components/pages/home/homepage.jsx';
import Login from "@components/pages/login/login.jsx";
import CreateSchedule from '@components/pages/createSchedule/createSchedule.jsx';

export default function App() {
    return (
        <Router>
			<div>
				<Routes>
					<Route path='/' element={<Homepage />} />
					<Route path ="/login" element={<Login />} />
                    <Route path ="/create-schedule" element={<CreateSchedule />} />
				</Routes>
			</div>
	    </Router>
    )
}